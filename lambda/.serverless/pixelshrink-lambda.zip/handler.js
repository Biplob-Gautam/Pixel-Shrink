import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from "@aws-sdk/client-s3";

import sharp from "sharp";

const s3 = new S3Client({
  region: "ap-south-1",
});

const ORIGINAL_BUCKET = process.env.ORIGINAL_BUCKET;
const PROCESSED_BUCKET = process.env.PROCESSED_BUCKET;

export const processImage = async (event) => {
  console.log("Event received:", JSON.stringify(event, null, 2));

  const record = event.Records[0];

  const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
  const pathParts = key.split("/");
  const jobId = pathParts[1];
  const fileName = pathParts[2];

  console.log("Processing:", key);

  const image = await s3.send(
    new GetObjectCommand({
      Bucket: ORIGINAL_BUCKET,
      Key: key,
    }),
  );

  const buffer = await streamToBuffer(image.Body);

  const processedBuffer = await sharp(buffer)
    .resize({
      width: 1200,
      withoutEnlargement: true,
    })
    .jpeg({
      quality: 70,
    })
    .toBuffer();

  const fileName = key.split("/").pop();
  const outputKey = `processed/${fileName}`;

  await s3.send(
    new PutObjectCommand({
      Bucket: PROCESSED_BUCKET,
      Key: outputKey,
      Body: processedBuffer,
      ContentType: "image/jpeg",
    }),
  );
  await fetch(`${process.env.BACKEND_URL}/api/v1/jobs/${jobId}/complete`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-lambda-secret": process.env.LAMBDA_SECRET,
    },
    body: JSON.stringify({
      processedKey: outputKey,
      processedSize: processedBuffer.length,
    }),
  });

  console.log("Uploaded:", outputKey);

  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Image processed successfully",
      outputKey,
    }),
  };
};

const streamToBuffer = async (stream) => {
  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(chunk);
  }

  return Buffer.concat(chunks);
};
